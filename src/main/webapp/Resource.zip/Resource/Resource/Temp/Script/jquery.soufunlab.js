﻿var fc_ErrorMsg = "No data to display.";
var fc_NoDataMsg = "";
var FC_AlertMsg = "?LoadDataErrorText=" + fc_ErrorMsg;

/*检查字符串是否为空*/
$.string.isNullOrEmpty = function (input) {
    if (input == "" || input == null) {
        return true;
    }
    else {
        return false;
    }
}
/*返回字符串字节数*/
$.string.ByteLength = function (input) {
    return input.replace(/[^x00-xFF]/g, '**').length;
}

/*提示信息*/
$.fn.tooltip = function (message) {
    $(this).each(function (i) {
        $(this).bt(message, { trigger: 'none', killTitle: false, fill: '#FEF693', strokeStyle: "#BFC9D9", strokeWidth: 1, spikeLength: 10, spikeGirth: 10, padding: 8, cornerRadius: 3, width: 150, hoverIntentOpts: { interval: 100, timeout: 100 }, cssStyles: { fontSize: '11px' } });
        $(this).btOn();
    });
}
$.layout = new Object();
$.layout.initialize = function () {
    $('body').layout({
        north__size: 70,
        west__size: 200,
        south__size: 30
    });
}
$.tabs = new Object();
$.tabs.openMenu = function (tabitemType, tabitemID, tabitemName, tabitemUrl) {

    var tabitemKey = "tabitem_" + tabitemType + "_" + tabitemID;

    var isOpen = false;

    $('.sltabitemcontent').each(function () {
        if ($(this).attr('id') == tabitemKey) {
            isOpen = true;
        }
    });

    if (isOpen) {
        $('#tabs').tabs("select", tabitemKey);
    }
    else {
        $('#tabs').tabs("destroy");
        var tabitemContent = $('<iframe class="sltabitemcontent" id="' + tabitemKey + '" frameborder="0" style="height: 100%; width: 100%; padding: 0px 0px 0px 0px;margin: 0px 0px 0px 0px;" src="' + tabitemUrl + '"></iframe>');
        tabitemContent.appendTo("#tabsContent");

        var tabitemHeader = $('<li><a class="sltabitemheaderbutton" href="#' + tabitemKey + '" title="' + tabitemType + "-" + tabitemName + '">' + tabitemName + ' <span class="ui-icon ui-icon-close"></span></a></li>');
        tabitemHeader.appendTo("#tabsHeader ul");
        tabitemHeader.find(".ui-icon-close").click(function (event) {
            $('#tabs').tabs("remove", tabitemKey);
        }).attr("title", "关闭");

        $('#tabs').tabs();
        $('#tabs').tabs("select", tabitemKey);
    }
}
$.menu = new Object();
$.menu.initialize = function (container, loadNodesUrl, autoLoadNodesUrl, nodeClick) {
    var tree = new dhtmlXTreeObject(container, "100%", "100%", 0);

    tree.setImagePath('/Resource/Script/dhtmlxtree/imgs/');

    if (autoLoadNodesUrl != null) {
        //异步加载数据的数据源
        tree.setXMLAutoLoading(autoLoadNodesUrl);
    }

    //初次加载数据
    tree.loadXML(loadNodesUrl);

    if (nodeClick != null) {
        tree.attachEvent("onClick", function (id) {
            nodeClick(id, this.getItemText(id), tree);
        });
    }
}
$.date = new Object();
$.date.format = function (date, format, zone) {
    format = format.replace("yyyy", date.getFullYear());
    format = format.replace("MM", (date.getMonth() + 1) > 10 ? (date.getMonth() + 1) : "0" + (date.getMonth() + 1))
    format = format.replace("dd", date.getDate() > 10 ? date.getDate() : "0" + date.getDate());
    format = format.replace("HH", date.getHours() > 10 ? date.getHours() : "0" + date.getHours());
    format = format.replace("mm", date.getMinutes() > 10 ? date.getMinutes() : "0" + date.getMinutes());
    format = format.replace("ss", date.getSeconds() > 10 ? date.getSeconds() : "0" + date.getSeconds());
    format = format.replace("fff", date.getMilliseconds() > 100 ? date.getMilliseconds() : "0" + (date.getMilliseconds() > 10 ? date.getMilliseconds() : "0" + date.getMilliseconds()));
    if (zone) {
        format = format.replace(/\b(\d)\b/g, '0$1 ');
    }
    return format;
}
$.date.now = function () {
    return $.date.format(new Date(), "yyyy-MM-dd HH:mm:ss.fff");
}

$.expandShrink = new Object();
$.expandShrink.initialize = function (triggerObj, expandContent, paddingTopHeight) {
    triggerObj = $.getjQueryObj(triggerObj);
    triggerObj.addClass("expandShrink-shrink");
    expandContent = $.getjQueryObj(expandContent);
    var expandContentHeight = expandContent.height();

    triggerObj.bind("click", function () {
        if (triggerObj.hasClass("expandShrink-expand")) {
            expandContent.next().css("padding-top", paddingTopHeight + "px");
            expandContent.show();
            triggerObj.removeClass("expandShrink-expand");
            triggerObj.addClass("expandShrink-shrink");
        }
        else {
            expandContent.next().css("padding-top", "0px");
            expandContent.hide();
            triggerObj.removeClass("expandShrink-shrink");
            triggerObj.addClass("expandShrink-expand");
        }
    });
}

$.getjQueryObj = function (obj) {
    return typeof obj === "string" ? $("#" + obj) : $(obj);
}