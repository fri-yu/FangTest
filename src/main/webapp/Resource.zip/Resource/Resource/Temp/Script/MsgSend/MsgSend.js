﻿//限制消息内容字数
function words_control1() {
    var curLength = $("#msgTitle").val().length;
    if (curLength > 30) {
        var num = $("#msgTitle").val().substr(0, 30);
        $("#msgTitle").val(num);
    }
    else {
        $("#remainWords1").text(30 - $("#msgTitle").val().length);
    }
}
//限制消息内容字数
function words_control2() {
    var curLength = $("#msgContent").val().length;
    if (curLength > 60) {
        var num = $("#msgContent").val().substr(0, 60);
        $("#msgContent").val(num);
    }
    else {
        $("#remainWords2").text(60 - $("#msgContent").val().length);
    }
}
//获取楼盘列表
function GetProjList() {
    var cityName = $("select[name=citySelect]").find('option:selected').text();
    $.post('/MsgManagement/LoadProj.do?', { cityName: cityName }, function (data) {
        if (data != "No") {
            $('#combobox').html('');
            for (var i = 0; i < data.length; i++) {
                $('#combobox').append('<option value=" + data[i] + ">' + data[i] + '</option>');
            }
        }
        else {
            $('#combobox').html('<option value="该城市没有楼盘">该城市暂时没有楼盘</option>');
        }
    });
}
//获取楼盘ID
function GetProjId() {
    var cityName = $("select[name=citySelect]").find('option:selected').text();
    var projName = $('.custom-combobox-input').val();
    if (cityName == '' || cityName == 'undefined' || projName == '' || projName == 'undefined') {
        return;
    }
    $.post('/MsgManagement/LoadProjId.do?', { cityName: cityName, projName: projName }, function (data) {
        if (data != "No") {
            //获取当前选中楼盘的消息列表
            LoadMsgList(1, data);
            //获取当前楼盘的下次发送时间
            $.post('/MsgManagement/GetNextSendTime.do?', { projId: data,projName:projName}, function (res) {
                if (res != null && res != '') {
                    var s = new Date(res);
                    v = s.getFullYear() + "-" + (s.getMonth() + 1) + "-" + s.getDate() + " " + "08:00:00.000";
                    var nextSendTime = new Date(v).getTime() + 7 * 24 * 60 * 60 * 1000;
                    var now = new Date().getTime();
                    var timeLeft = nextSendTime - now;
                    if (timeLeft <= 0) {
                        $('#nextSendTime').css('display', 'none');
                        $('.btnSend').attr('disabled', false);
                        $('#msgTitle').attr('disabled', false);
                        $('#msgContent').attr('disabled', false);
                        return;
                    }
                    timeRemain(timeLeft);
                    $('#nextSendTime').css('display', 'block');
                    $('.btnSend').attr('disabled', true);
                    $('#msgTitle').attr('disabled', true);
                    $('#msgContent').attr('disabled', true);
                }
                else {
                    $('#nextSendTime').css('display', 'none');
                    $('.btnSend').attr('disabled', false);
                    $('#msgTitle').attr('disabled', false);
                    $('#msgContent').attr('disabled', false);
                }
            });
        }
        else {
            //弹出出错对话框
            $("#dialog-error").dialog({
                resizable: false,
                height: 140,
                modal: true,
                buttons: {
                    "确定": function () {
                        $(this).dialog("close");
                    }
                }
            });
        }
    });
}
//发送消息
function SendMsg() {
    var cityName = $("select[name=citySelect]").find('option:selected').text();
    var projName = $("select[id=combobox]").find('option:selected').text();
    var msgTitle = $('#msgTitle').val();
    var msgContent = $('#msgContent').val();
    if (projName == '' || projName == undefined) {
        alert("请填写完整数据，再行提交");
        return;
    }
    if (msgTitle == '' || msgTitle == undefined) {
        alert("请填写完整数据，再行提交");
        return;
    }
    if (msgContent == '' || msgContent == undefined) {
        alert("请填写完整数据，再行提交");
        return;
    }
    $.post('/MsgManagement/LoadProjId.do?', { cityName: cityName, projName: projName }, function (data) {
        //将楼盘ID发送给前台进行大数据匹配，返回网友信息
        $.post('/MsgManagement/InsertToQueue.do?', { projId: data }, function (res) {
            if (res == "yes") {
                $.post('/MsgManagement/SendMsg.do?', { cityName: cityName, projName: projName, projId: data, msgTitle: msgTitle, msgContent: msgContent }, function (res) {
                    if (res == "1" || res=='2') {
                        LoadMsgList(1);
                        $('#msgTitle').val('');
                        $('#msgContent').val('');
                    }
                    else {
                        alert("服务器正忙，请稍后再试！");
                    }
                });
            }
        });
    });
};
//加载消息列表并分页
function LoadMsgList(pageIndex, projId) {
    $.post('/MsgManagement/LoadMsgList.do?', {
        pageIndex: pageIndex,
        projId: projId
    }, function (msg) {
        if (msg.List != null) {
            $('#msgList').html('');
            $.each(msg.List, function (index, item) {
                var temp;
                if (item.IsSend==0) {
                    temp = '匹配中';
                }
                else if (item.IsSend==1) {
                    temp = '发送中';
                }
                else {
                    temp = '发送成功';
                }
                $('#msgList').append('<div>' +
            '&nbsp&nbsp 城市：&nbsp<span id="cityNameDetail" name="cityNameDetail">' + item.CityName + '</span>' +
            '&nbsp&nbsp&nbsp 楼盘名称： &nbsp<span id="projNameDetail" name="projNameDetail">' + item.ProjName + '</span>' +
            '&nbsp&nbsp&nbsp ' + new Date(parseInt(item.SendTime.substr(6, 13), 10)).pattern("yyyy-MM-dd H:mm:ss") + '' +
        '</div>' +
        '<div style="margin-top: 10px">' +
            '&nbsp&nbsp 标题：  <span id="msgTitleDetail" name="msgTitleDetail" style="font-weight: 700">' + item.MsgTitle + '</span>' +
        '</div>' + '<div style="text-align:center">&nbsp&nbsp 发送状态:<span id="SendState" name="SendState"><span style="color: red">' + temp + '</span></span></div>' +
        '<div style="margin-top: 4px">' +
            '&nbsp&nbsp' +
        '<span id="msgContentDetail" name="msgContentDetail">' + item.MsgContent + '</span>' +
        '</div>' +
        '<hr style="margin-right: 200px;margin-left:20px; border-color: lightgrey; border-style: dashed" />' +
        '<div style="margin-top: 5px">' +
            '&nbsp&nbsp 匹配用户:<span id="matchCustomerNum" name="matchCustomerNum"><span style="color: red">' + item.MatchCustomer + '</span></span>' +
            '&nbsp&nbsp 发送条数:<span id="msgSendNum" name="msgSendNum"><span style="color: red">' + item.PushNum + '</span></span>' +
            '&nbsp&nbsp 发送成功:<span id="msgSendOKNum" name="msgSendOKNum"><span style="color: red">' + item.PushSuccess + '</span></span>' +
            '&nbsp&nbsp 用户打开:<span id="CustomerOpenNum" name="CustomerOpenNum"><span style="color: red">' + item.CustomerOpen + '</span></span>' +
            '&nbsp&nbsp IM回复:<span id="IMReplyNum" name="IMReplyNum"><span style="color: red">' + item.ImReply + '</span></span>' +
            '&nbsp&nbsp 手机回复:<span id="TelReplyNum" name="TelReplyNum"><span style="color: red">' + item.TelReply + '</span></span>' +
            '&nbsp&nbsp 400回复:<span id="400ReplyNum" name="400ReplyNum"><span style="color: red">' + item.Four00Reply + '</span></span>' +
            '&nbsp&nbsp 订单:<span id="OrdersNum" name="OrdersNum"><span style="color: red">' + item.Orders + '</span></span>' +
        '</div>' +
        '<br />' +
        '<hr style="margin-right: 200px" />');
            })
        }
        else {
            $('#msgList').html('<div style="color:red;margin-left:210px;font-size:20px">该楼盘暂无推送消息哦！<div>');
        }
        $('.page_nav').html(msg.Pager);
        $('.page').each(function () {
            $(this).attr('href', 'javascript:Goto(' + $(this).attr("href") + ',' + projId + ')');
        });
    });
}
//跳转到指定页
function Goto(pageIndex, projId) {
    LoadMsgList(pageIndex, projId);
}
//倒计时
function timeRemain(intDiff) {
    window.setInterval(function () {
        var day = 0,
            hour = 0,
            minute = 0,
            second = 0;//时间默认值        
        if (intDiff > 0) {
            day = Math.floor(intDiff / (1000 * 60 * 60 * 24));
            hour = Math.floor((intDiff - day * 24 * 60 * 60 * 1000) / (1000 * 60 * 60));
            minute = Math.floor((intDiff - day * 24 * 60 * 60 * 1000 - hour * 60 * 60 * 1000) / (1000 * 60));
            second = Math.floor((intDiff - day * 24 * 60 * 60 * 1000 - hour * 60 * 60 * 1000 - minute * 60 * 1000) / 1000);
        }
        if (minute <= 9) minute = '0' + minute;
        if (second <= 9) second = '0' + second;
        $('#day_show').html("");
        $('#hour_show').html("");
        $('#minute_show').html("");
        $('#second_show').html("");
        $('#day_show').html(day + "天");
        $('#hour_show').html('<s id="h"></s>' + hour + '时');
        $('#minute_show').html('<s></s>' + minute + '分');
        $('#second_show').html('<s></s>' + second + '秒');
        intDiff -= 1000;
    }, 1000);
}
//Jquery AutoComplete
(function ($) {
    $.widget("custom.combobox", {
        _create: function () {
            this.wrapper = $("<span>")
                .addClass("custom-combobox")
                .insertAfter(this.element);

            this.element.hide();
            this._createAutocomplete();
            this._createShowAllButton();
        },

        _createAutocomplete: function () {
            var selected = this.element.children(":selected"),
                value = selected.val() ? selected.text() : "";

            this.input = $("<input>")
                .appendTo(this.wrapper)
                .val(value)
                .attr("title", "")
                .addClass("custom-combobox-input ui-widget ui-widget-content ui-state-default ui-corner-left")
                .autocomplete({
                    delay: 0,
                    minLength: 0,
                    source: $.proxy(this, "_source")
                })
                .tooltip({
                    tooltipClass: "ui-state-highlight"
                });

            this._on(this.input, {
                autocompleteselect: function (event, ui) {
                    ui.item.option.selected = true;
                    this._trigger("select", event, {
                        item: ui.item.option
                    });
                },

                autocompletechange: "_removeIfInvalid"
            });
        },

        _createShowAllButton: function () {
            var input = this.input,
                wasOpen = false;

            $("<a>")
                .attr("tabIndex", -1)
                .attr("title", "显示所有")
                .tooltip()
                .appendTo(this.wrapper)
                .button({
                    icons: {
                        primary: "ui-icon-triangle-1-s"
                    },
                    text: false
                })
                .removeClass("ui-corner-all")
                .addClass("custom-combobox-toggle ui-corner-right")
                .mousedown(function () {
                    wasOpen = input.autocomplete("widget").is(":visible");
                })
                .click(function () {
                    input.focus();

                    // Close if already visible
                    if (wasOpen) {
                        return;
                    }

                    // Pass empty string as value to search for, displaying all results
                    input.autocomplete("search", "");
                });
        },

        _source: function (request, response) {
            var matcher = new RegExp($.ui.autocomplete.escapeRegex(request.term), "i");
            response(this.element.children("option").map(function () {
                var text = $(this).text();
                if (this.value && (!request.term || matcher.test(text)))
                    return {
                        label: text,
                        value: text,
                        option: this
                    };
            }));
        },

        _removeIfInvalid: function (event, ui) {

            // Selected an item, nothing to do
            if (ui.item) {
                return;
            }

            // Search for a match (case-insensitive)
            var value = this.input.val(),
                valueLowerCase = value.toLowerCase(),
                valid = false;
            this.element.children("option").each(function () {
                if ($(this).text().toLowerCase() === valueLowerCase) {
                    this.selected = valid = true;
                    return false;
                }
            });

            // Found a match, nothing to do
            if (valid) {
                return;
            }

            // Remove invalid value
            this.input
                .val("")
                .attr('id', value + 'projNameSelect')
                .tooltip("open");
            this.element.val("");
            this._delay(function () {
                this.input.tooltip("close").attr("title", "");
            }, 2500);
            this.input.autocomplete("instance").term = "";
        },

        _destroy: function () {
            this.wrapper.remove();
            this.element.show();
        }
    });
})(jQuery);

$(function () {
    $("#combobox").combobox();
    $("#toggle").click(function () {
        $("#combobox").toggle();
    });
});