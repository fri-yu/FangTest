﻿; ;
//需要Jquery swfobject.js的支持
var swfHelper = {
    init: function(option) {
        option = option || {};
        var d = {
            swfPlate: "/Scripts/ofc/open-flash-chart.swf",
            div: option.chart,
            width: this.browerJudgeSetWidth(),
            height: option.height,
            flashVersion: "9.0.0",
            emptyPlate: { "data-file": "/Scripts/ofc/empty.txt" }
        };

        d = jQuery.extend(d, option);

        swfobject.embedSWF(d.swfPlate, d.div, d.width, d.height, d.flashVersion, null, d.emptyPlate);
    },
    browerJudgeSetWidth: function() {
        if (jQuery.browser.msie && (jQuery.browser.version == "6.0") && !jQuery.support.style)
            return "700"; //ie6不支持min-width需要在这设置flash的宽度 撑开div
        else
            return "95%";
    }
}