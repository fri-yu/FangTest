﻿//条形图数值 
function Get_Tiao(ContenID, Fromtext,Ydata) {
    var chartid = "#" + ContenID;//div ID值
    $(function () {
        $(chartid).highcharts({
            chart: {
                type: 'bar',               
            },
            title: {
                text: null
            },
            subtitle: {
                //text: 'Source: Wikipedia.org'                                  
            },
            xAxis: {
                //categories: ['PC', 'Wap', 'App', '扫码', '后台录入', '搜房电话', '电商案场', '新房帮录入', '新房委托'],
                categories: Fromtext,
                title: {
                    text: null
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            tooltip: {
                //valueSuffix: ' millions'                                       
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                borderWidth: 0,
                backgroundColor: '#FFFFFF',
                shadow: false

            },
            credits: {
                enabled: false
            },
            series: Ydata
        });
    });
}

//条形图比例
function Get_TiaoRate(ContenID, Fromtext, Ydata) {
    var chartid = "#" + ContenID;//div ID值
    $(function () {
        $(chartid).highcharts({
            chart: {
                type: 'bar'
            },
            title: {
                text: null
            },
            subtitle: {
                //text: 'Source: Wikipedia.org'                                  
            },
            xAxis: {
                //categories: ['PC', 'Wap', 'App', '扫码', '后台录入', '搜房电话', '电商案场', '新房帮录入', '新房委托'],
                categories: Fromtext,
                title: {
                    text: null
                }
            },
            yAxis: {
                title: '',
                labels: {
                    formatter: function () {
                        return this.value + '%';
                    }
                }
            },
            tooltip: {      
                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                    '<td style="padding:0"><b>{point.y:.1f} %</b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            plotOptions: {              
                  
                bar: {
                    dataLabels: {
                        formatter: function () {
                            return this.y + '%';
                        },
                        enabled: true, // dataLabels设为true
                    }
                }
            },                        
          
            legend: {
                borderWidth: 0,
                backgroundColor: '#FFFFFF',
                shadow: false

            },
            credits: {
                enabled: false
            },
            series: Ydata
        });
    });
}
//环形图比例
function GetCircularMethodRate(ContenID, Chartdata) {
    var chartid = "#" + ContenID;//div ID值
    $(function () {
        $(chartid).highcharts({
            chart: {
                //backgroundColor: '#F4F4F4',
                type: 'pie' //图表类型还是pie图

            },
            title: {
                text: '',  //标题
                //x: -110
                align: "left",
                style: {
                    fontSize: '16px',
                    color: 'black', //总和数据标签的颜色
                    fontWeight: 'bold',
                },
            },
            subtitle: {
                text: '',
                x: -20
            },
            legend: {
                layout: 'vertical',
                align: 'right',  //显示位置
                verticalAlign: 'middle',
                borderWidth: 0
            },
            plotOptions: {
                pie: {
                    size: 120,
                    innerSize: '100%', //也可以配置为10%的百分比形式
                    dataLabels: {
                        enabled: false
                    },
                    colors: [
                       '#6EBFFF',
                       '#FFDA7C',
                       '#FF70A0',
                        '#00F8F8',
                        '#65CB65',
                       '#F0621F',
                       '#CC0000',
                       '#68217A',
                       '#00008F'
                    ],
                    showInLegend: true

                }
            },

            tooltip: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: Chartdata           
        });
    });
}

//加载数据条形图比例
function GetTiaoColumnData(Chartdiv, City,SatarTime, EndTime, Fromtext, Mediumflag) {
    $.ajax({
        type: "POST",
        url: "GetColumnChart.do?t=" + Math.random(),
        cache: false,
        data: {
            City:City,
            Begintime: SatarTime,
            Endtime: EndTime,
            Fromtext: Fromtext,
            Mediumflag: Mediumflag
        },
        success: function (data) {
            if (data != null && data != "") {
                var Result = data.split('&');
                var Xjson = eval(Result[1]);//X轴数据                 
                var DataJson = eval(Result[0]); //数据
                Get_TiaoRate(Chartdiv, Xjson, DataJson);
            }
        }
    });
}

//加载数据环形图比例
function GetPieColumnData(Chartdiv, PieType,City, SatarTime, EndTime, Fromtext, Mediumflag) {
    $.ajax({
        type: "POST",
        url: "GetPieColumnChart.do?t=" + Math.random(),
        cache: false,
        data: {
            PieType:PieType,
            City: City,
            Begintime: SatarTime,
            Endtime: EndTime,
            StrSource: Fromtext,
            Mediumflag: Mediumflag
        },
        success: function (data) {
            if (data != null && data != "") {
                var DataJson = eval(data); //数据
                GetCircularMethodRate(Chartdiv, DataJson);
            }
        }
    });
}

//加载数据条形图数值
function GetTiaoColumnNum(Chartdiv, City, SatarTime, EndTime, Fromtext, Mediumflag) {
    $.ajax({
        type: "POST",
        url: "GetColumnChartNum.do?t=" + Math.random(),
        cache: false,
        data: {
            City: City,
            Begintime: SatarTime,
            Endtime: EndTime,
            Fromtext: Fromtext,
            Mediumflag: Mediumflag
        },
        success: function (data) {
            if (data != null && data != "") {
                var Result = data.split('&');
                var Xjson = eval(Result[1]);//X轴数据                 
                var DataJson = eval(Result[0]); //数据
                Get_Tiao(Chartdiv, Xjson, DataJson);
            }
        }
    });
}



////柱状图带百分号 
//function GetZhanbiTuMethod(ContentID, XData, YData) {
//    var charid = "#" + ContentID;//div ID值
//    $(charid).highcharts({
//        chart: {
//            type: 'column'
//        },
//        title: {
//            text: '各来源转化占比',
//            align: 'left'
//        },
//        subtitle: {
//            text: ''
//        },
//        xAxis: {
//            categories: XData,
//            labels: { rotation: -45, y: 30 },
//            title: {
//                text: null
//            }
//        },

//        yAxis: {
//            title: '',
//            labels: {
//                formatter: function () {
//                    return this.value + '%';
//                }
//            }
//        },

//        tooltip: {
//            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
//            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
//                '<td style="padding:0"><b>{point.y:.1f} %</b></td></tr>',
//            footerFormat: '</table>',
//            shared: true,
//            useHTML: true
//        },
//        plotOptions: {
//            column: {
//                dataLabels: {
//                    formatter: function () {
//                        return this.y + '%';
//                    },
//                    enabled: true, // dataLabels设为true

//                },
//                pointPadding: 0.1,
//                borderWidth: 0
//            }
//            //column: {
//            //    pointPadding: 0.2,
//            //    borderWidth: 0
//            //}
//        },
//        series: YData,
//        credits: {
//            enabled: false
//        }
//    });

//}


////柱状图数值
//function GetNumTuMethod(ContentID, XData, YData) {
//    var charid = "#" + ContentID;//div ID值
//    $(charid).highcharts({
//        chart: {
//            type: 'column'
//        },
//        title: {
//            text: '各来源转化占比',
//            align: 'left'
//        },
//        subtitle: {
//            text: ''
//        },
//        xAxis: {
//            categories: XData,
//            labels: { rotation: -45, y: 30 }
//        },

//        yAxis: {
//            title: ''
//        },

//        tooltip: {
//            valueSuffix: '个',
//            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
//            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
//                '<td style="padding:0"><b>{point.y} </b></td></tr>',
//            footerFormat: '</table>',
//            shared: true,
//            useHTML: true
//        },
//        plotOptions: {
//            column: {
//                dataLabels: {
//                    enabled: true, // dataLabels设为true
//                },
//                pointPadding: 0.1,
//                borderWidth: 0
//            }
//        },
//        series: YData,
//        credits: {
//            enabled: false
//        }
//    });
//}

////加载图中数据
//function GetColumnData(Chartdiv, SatarTime, EndTime, Fromtext, Mediumflag) {
//    $.ajax({
//        type: "POST",
//        url: "GetColumnChart.do?t=" + Math.random(),
//        cache: false,
//        data: {
//            Begintime: SatarTime,
//            Endtime: EndTime,
//            Fromtext: Fromtext,
//            Mediumflag: Mediumflag
//        },
//        success: function (data) {
//            if (data != null && data != "") {
//                var Result = data.split('&');
//                var Xjson = eval(Result[1]);//X轴数据                 
//                var DataJson = eval(Result[0]); //数据
//                GetZhanbiTuMethod(Chartdiv, Xjson, DataJson);
//            }
//            //else {
//            //    $("#ShowColumnChart").html("<div style='width: 100%; height: 300px;font-size:18px;text-align:center;'><span style='color: #F00'>无数据</span></div>");

//            //}
//        }
//    });
//}

////加载图中数据
//function GetColumnDataNum(Chartdiv, SatarTime, EndTime, Fromtext, Mediumflag) {
//    $.ajax({
//        type: "POST",
//        url: "GetColumnChartNum.do?t=" + Math.random(),
//        cache: false,
//        data: {
//            Begintime: SatarTime,
//            Endtime: EndTime,
//            Fromtext: Fromtext,
//            Mediumflag: Mediumflag
//        },
//        success: function (data) {
//            if (data != null && data != "") {
//                var Result = data.split('&');
//                var Xjson = eval(Result[1]);//X轴数据                 
//                var DataJson = eval(Result[0]); //数据
//                GetNumTuMethod(Chartdiv, Xjson, DataJson);
//            }
//            //else {
//            //    $("#ShowColumnChartNum").html("<div style='width: 100%; height: 300px;font-size:18px;text-align:center;'><span style='color: #F00'>无数据</span></div>");

//            //}
//        }
//    });
//}

