﻿function GetLineMethod(ContentID, ChartText, ChartXContent, ChartSuffix, ChartData, ShowValue) {
    var charid = "#" + ContentID;//div ID值
    $(charid).highcharts({
        //chart: {
        //    //width: 1100,
        //    //height: 300
        //},
        title: {
            text: ChartText,  //标题
            x: -140          
        },
        subtitle: {
            text: '',
            x: -20
        },
        xAxis: {
            categories: ChartXContent,  //要显示的X轴的值
            labels: { rotation: -45, y: 30 }
        },
        yAxis: {
            title: {
                text: ''
            },
            min: 0,
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ChartSuffix   //单位，比如“人”
        },
        plotOptions: { line: { dataLabels: { enabled: ShowValue }, enableMouseTracking: true } },
        legend: {
            //layout: 'vertical',
            //align: 'center',  //显示位置
            //verticalAlign: 'middle',
            borderWidth: 0
        },
        series: ChartData,  //最终显示的数据
       // setSize: { width:'100%' },//Number width, Number height, [Mixed animation])
        credits: {
            enabled: false
        }
    });

}
//饼形图
function Get_Pie(ContenID, ChartTest, Cdata,Cwidth,Csubtitle) {
    var chartid = "#" + ContenID;//div ID值
    $(function () {
        $(chartid).highcharts({
            chart: {
                width: Cwidth,//400,
                height: 300
                //plotBackgroundColor: null,
                //plotBorderWidth: null,
                //plotShadow: false
            },
            title: {
                text: ChartTest
            },
            subtitle: {
                //text: '项目执行期内所有客户数据',
                text: Csubtitle,
                style: {
                    color: '#DA0000',
                    fontSize: '12px'
                },
                x: -6
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            legend: {
                //layout: 'vertical',
                //align: 'center',  //显示位置
                //verticalAlign: 'middle',
                borderWidth: 0
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        color: '#000000',
                        distance: 2,//数据标签距离边缘的距离值 为负数就越靠近饼图中心
                        rotation: 0,//数据标签旋转角度
                        connectorPadding:3,
                        connectorColor: '#000000',//<b>{point.name}</b>: {point.percentage:.1f} %
                        //format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                        format: '<b>{point.name}</b>, {point.y},{point.percentage:.1f} %'

                    },
                    showInLegend:true
                }
            },
            noData: {
                attr: null,
                position: { "x": 0, "y": 0, "align": "center", "verticalAlign": "middle" },
                style: { "fontSize": "12px", "fontWeight": "bold", "color": "#60606a" }
            },
            series: Cdata,           
            credits: {
                enabled: false
            }
        });
    });		

}


    //客户趋势(来电，订单)折线
function GetCustomQS(Chartdiv, SatarTime, EndTime, SelectCity, ProjName, NewCode, isPooldata, pinPaiName) {
    $.ajax({
            async: true,
            type: "POST",
            url: "GetCustomerFrom.do?t=" + Math.random(),
            cache: false,
            data: {
                Begintime: SatarTime,
                Endtime: EndTime,
                City: SelectCity,
                ProjName: ProjName,
                Newcode: NewCode,
                isPooldata: isPooldata,
                pinPaiName:pinPaiName
            },
            success: function (data) {
                if (data != null&&data!="") {
                    var Result = data.split('&');
                    var Xjson = Round30Y(eval(Result[0]));//数据                 
                    var DataJson = Round30X(eval(Result[1]));//时间
                    GetLineMethod(Chartdiv, "订单、到访及认购趋势图", DataJson, "个", Xjson, false); //折线图 ShowChartPie
                }
                else {                   
                    $("#ShowChartCustom").html("<div style='width: 100%; height: 300px;font-size:18px;text-align:center;'><span style='color: #F00'>客户趋势图无数据</span></div>");

                }
            }
        });
}

//客户来源(线图)
function GetDingDanxian(Chartdiv, SatarTime, EndTime, SelectCity, ProjName, NewCode, isPooldata, pinPaiName) {
    $.ajax({
        async: true,
        type: "POST",
        url: "GetCusDingdan.do?t=" + Math.random(),
        cache: false,
        data: {
            Begintime: SatarTime,
            Endtime: EndTime,
            City: SelectCity,
            ProjName: ProjName,
            Newcode: NewCode,
            isPooldata: isPooldata,
            pinPaiName: pinPaiName
        },
        success: function (data) {
            if (data != null && data != "") {
                var ddresult = data.split("&");
                var resultF = Round30Y(eval(ddresult[0]));
                var DataJson = Round30X(eval(ddresult[1]));//时间
                //Get_Pie(Chartdiv, "订单来源", resultF, 350, "");//饼图     
                //GetChartData(ddresult[1]);
                GetLineMethod(Chartdiv, "订单来源趋势图", DataJson, "个", resultF, false); //折线图 ShowChartPie
            }
            else {
                $("#ShowChartLine").html("<div style='width: 100%; height: 300px;font-size:18px;text-align:center;'><span style='color: #F00'>客户趋势图无数据</span></div>");

            }
        }
    });
}
function Round30X(orginalX) {
    if (orginalX.length > 30) {
        var rtn = new Array();
        var step = Math.ceil(orginalX.length / 30);
        for (var i = 0; i < orginalX.length; i++) {
            if (!(i % step))
            {
                rtn.push(orginalX[i]);
            }
        }
        return rtn;
    } else {
        return orginalX;
    }
}
function Round30Y(orginalY) {
    for (var i = 0; i < orginalY.length; i++) {
        if (orginalY[i].data.length > 30) {
            var rtn = new Array();
            var step = Math.ceil(orginalY[i].data.length / 30);
            for (var j = 0; j < orginalY[i].data.length; j++) {
                if (!(j % step))
                {
                    rtn.push(orginalY[i].data[j]);
                }
            }
        }
        else {
            return orginalY;
        }
        orginalY[i].data = rtn;
    }
    return orginalY;
}
function GetTiaoTu(Chartdiv, SatarTime, EndTime, SelectCity, ProjName, NewCode, isPooldata, pinPaiName) {
    $.ajax({
        async: true,
        type: "POST",
        url: "GetTiaoTuStatics.do?t=" + Math.random(),
        cache: false,
        data: {
            Begintime: SatarTime,
            Endtime: EndTime,
            City: SelectCity,
            ProjName: ProjName,
            Newcode: NewCode,
            isPooldata: isPooldata,
            pinPaiName:pinPaiName
        },
        success: function (data) {
            if (data != null && data != "") {
                var resultF = eval(data);
                //GetTiaoTuMethod(Chartdiv, resultF);//条形图  
                abc(Chartdiv, resultF);
            }
            else {
                $("#ShowTiaoTu").html("<div style='width: 100%; height: 300px;font-size:18px;text-align:center;'><span style='color: #F00'>客户来源无数据</span></div>");

            }
        }
    });

}
//条形图
function abc(ContenID, Ydata)
{
    var chartid = "#" + ContenID;//div ID值
    $(function () {
        $(chartid).highcharts({
            chart: {
                type: 'bar'
            },
            title: {
                text: null
            },
            subtitle: {
                //text: 'Source: Wikipedia.org'                                  
            },
            xAxis: {
                categories: ['PC', 'Wap', 'App', '扫码', '后台录入', '搜房电话', '电商案场', '新房帮录入', '新房委托'],
                title: {
                    text: null
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            tooltip: {
                //valueSuffix: ' millions'                                       
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                borderWidth: 0,
                backgroundColor: '#FFFFFF',
                shadow: false

            },
            credits: {
                enabled: false
            },
            series: Ydata
        });
    });
}


    //客户来源(饼形图)
function GetCustomerFrom(Chartdiv, SatarTime, EndTime, SelectCity, ProjName, NewCode, isPooldata,pinPaiName) {
    $.ajax({
        async: true,
        type: "POST",
        url: "GetCus.do?t=" + Math.random(),
        cache: false,
        data: {
            Begintime: SatarTime,
            Endtime: EndTime,
            City: SelectCity,
            ProjName: ProjName,
            Newcode: NewCode,
            isPooldata: isPooldata,
            pinPaiName:pinPaiName
        },
        success: function (data) {
            if (data != null && data != "") {
                var ddresult = data.split("#");                    
                var resultF = eval(ddresult[0]);
                Get_Pie(Chartdiv, "订单来源分析图", resultF, 350, "");//饼图     
                //GetChartData(ddresult[1]);
            }
            else {               
                $("#ShowChartPieCus").html("<div style='width: 100%; height: 300px;font-size:18px;text-align:center;'><span style='color: #F00'>客户来源无数据</span></div>");

            }
        }
    });
}


