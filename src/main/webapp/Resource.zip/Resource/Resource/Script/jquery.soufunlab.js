﻿var fc_ErrorMsg = "No data to display.";
var fc_NoDataMsg = "";
var FC_AlertMsg = "?LoadDataErrorText=" + fc_ErrorMsg;

/*检查字符串是否为空*/
$.string.isNullOrEmpty = function (input) {
    if (input == "" || input == null) {
        return true;
    }
    else {
        return false;
    }
}
/*返回字符串字节数*/
$.string.ByteLength = function (input) {
    return input.replace(/[^x00-xFF]/g, '**').length;
}

/*提示信息*/
$.fn.tooltip = function (message) {
    $(this).each(function (i) {
        $(this).bt(message, { trigger: 'none', killTitle: false, fill: '#FEF693', strokeStyle: "#BFC9D9", strokeWidth: 1, spikeLength: 10, spikeGirth: 10, padding: 8, cornerRadius: 3, width: 150, hoverIntentOpts: { interval: 100, timeout: 100 }, cssStyles: { fontSize: '11px' } });
        $(this).btOn();
    });
}
$.layout = new Object();
$.layout.initialize = function () {
    $('body').layout({
        north__size: 70,
        west__size: 200,
        south__size: 30
    });
}
$.tabs = new Object();
$.tabs.refreshMenu = function (tabitemType, tabitemID, tabitemName, tabitemUrl) {
    var flag = 0;
    $('.sltabitemheaderbutton').each(function () {
        if ($(this).text().replace(/\s/g, "") == tabitemName) {
            $('#tabs').tabs("select", $(this).attr("href").split("#")[1]);
            $($(this).attr("href")).attr("src", tabitemUrl);
            flag++;
        }
    });
    if (flag == 0) {
        $.tabs.openMenu(tabitemType, tabitemID, tabitemName, tabitemUrl);
    }
}
$.tabs.closeMenu = function (closeTabitemName) {
    $('.sltabitemheaderbutton').each(function () {
        if ($(this).text().replace(/\s/g, "") == closeTabitemName) {
            $('#tabs').tabs("remove", $(this).attr("href").split("#")[1]);
        }
    });

}
$.tabs.openParentMenu = function (tabitemType, tabitemID, parenttabitemName, tabitemUrl, isOpenFromPage) {
    var flag = 0;
    $(window.parent.document).find('.sltabitemheaderbutton').each(function () {
        if ($(this).text().replace(/\s/g, "") == parenttabitemName) {
            $(window.parent.document).find('#tabs').tabs("select", $(this).attr("href").split("#")[1]);
            flag++;
        }
    });
    if (flag == 0) {
        $.tabs.openMenu(tabitemType, tabitemID, parenttabitemName, tabitemUrl, isOpenFromPage);
    }
}
$.tabs.openMenu = function (tabitemType, tabitemID, tabitemName, tabitemUrl, isOpenFromPage, tipName) {
    //
    if (tipName == null || tipName.length <= 0) {
        tipName = tabitemName;
    }
    //如果从页面打开新tab,则调用parent
    if (isOpenFromPage) {
        var tabitemKey = "tabitem_" + tabitemType + "_" + tabitemID;
        var isOpen = false;

        $(window.parent.document).find('.sltabitemcontent').each(function () {
            if ($(this).attr('id') == tabitemKey) {
                isOpen = true;
            }
        });

        if (isOpen) {
            $(window.parent.document).find('#tabs').tabs("select", tabitemKey);
        }
        else {
            $(window.parent.document).find('#tabs').tabs("destroy");
            var tabitemContent = $('<iframe class="sltabitemcontent" id="' + tabitemKey + '" frameborder="0" style="height: 100%; width: 100%; padding: 0px 0px 0px 0px;margin: 0px 0px 0px 0px;" src="' + tabitemUrl + '"></iframe>');
            tabitemContent.appendTo($(window.parent.document).find('#tabsContent'));

            var tabitemHeader = $('<li><a class="sltabitemheaderbutton" href="#' + tabitemKey + '" title="' + tabitemType + "-" + tipName + '">' + tabitemName + ' <span class="ui-icon ui-icon-close"></span></a></li>');
            tabitemHeader.appendTo($(window.parent.document).find("#tabsHeader ul"));
            tabitemHeader.find(".ui-icon-close").click(function (event) {
                $(window.parent.document).find('#tabs').tabs("remove", tabitemKey);
            }).attr("title", "关闭");

            $(window.parent.document).find('#tabs').tabs();
            $(window.parent.document).find('#tabs').tabs("select", tabitemKey);
        }
    }
    else {
        //从左侧菜单打开tab
        var tabitemKey = "tabitem_" + tabitemType + "_" + tabitemID;
        var isOpen = false;
        $('.sltabitemcontent').each(function () {
            if ($(this).attr('id') == tabitemKey) {
                isOpen = true;
            }
        });

        if (isOpen) {
            $('#tabs').tabs("select", tabitemKey);
        }
        else {
            $('#tabs').tabs("destroy");
            var tabitemContent = $('<iframe class="sltabitemcontent" id="' + tabitemKey + '" frameborder="0" style="height: 100%; width: 100%; padding: 0px 0px 0px 0px;margin: 0px 0px 0px 0px;" src="' + tabitemUrl + '"></iframe>');
            tabitemContent.appendTo("#tabsContent");

            var tabitemHeader = $('<li><a class="sltabitemheaderbutton" href="#' + tabitemKey + '" title="' + tabitemType + "-" + tipName + '">' + tabitemName + ' <span class="ui-icon ui-icon-close"></span></a></li>');
            tabitemHeader.appendTo("#tabsHeader ul");
            tabitemHeader.find(".ui-icon-close").click(function (event) {
                $('#tabs').tabs("remove", tabitemKey);
            }).attr("title", "关闭");

            $('#tabs').tabs();
            $('#tabs').tabs("select", tabitemKey);
        }
    }
}
$.tabs.openMenu0 = function (tabitemName, tabitemUrl) {
    var tabitemKey = tabitemName;
    var isOpen = false;
    $('.sltabitemcontent').each(function () {
        if ($(this).attr('id') == tabitemKey) {
            isOpen = true;
        }
    });

    if (isOpen) {
        $('#tabs').tabs("select", tabitemKey);
    }
    else {
        $('#tabs').tabs("destroy");
        var tabitemContent = $('<iframe class="sltabitemcontent" id="' + tabitemKey + '" frameborder="0" style="height: 100%; width: 100%; padding: 0px 0px 0px 0px;margin: 0px 0px 0px 0px;" src="' + tabitemUrl + '"></iframe>');
        tabitemContent.appendTo("#tabsContent");

        var tabitemHeader = $('<li><a class="sltabitemheaderbutton" href="#' + tabitemKey + '" title="sys-' + tabitemKey + '">' + tabitemKey + ' <span class="ui-icon ui-icon-close"></span></a></li>');
        tabitemHeader.appendTo("#tabsHeader ul");
        tabitemHeader.find(".ui-icon-close").click(function (event) {
            $('#tabs').tabs("remove", tabitemKey);
        }).attr("title", "关闭");

        $('#tabs').tabs();
        $('#tabs').tabs("select", tabitemKey);
    }
    //如果页面中有search函数则执行之
    var index;
    var iframes = document.getElementsByTagName("iframe");
    for (index = 0; index < iframes.length; index++) {
        if (iframes[index].getAttribute('id') == tabitemKey) {
            if (iframes[index].contentWindow.search && typeof (iframes[index].contentWindow.search) == 'function') {
                iframes[index].contentWindow.search();
            }
            break;
        }
    }
}
$.tabs.closeSelf = function () {
    var index;
    var iframes = window.parent.document.getElementsByTagName("iframe");
    var winurl = window.location.pathname + window.location.search;
    if (!(winurl.indexOf('%') + 1)) {
        winurl = encodeURI(winurl);
    }
    for (index = 0; index < iframes.length; index++) {
        if (encodeURI(iframes[index].getAttribute("src")) == winurl) {
            break;
        }
    }
    index--;//首页没有.sltabitemheaderbutton
    var tabName = window.parent.$('a.sltabitemheaderbutton:eq(' + index + ')').attr('href').substr(1);
    window.parent.$.tabs.closeMenu(tabName);
}
$.menu = new Object();
$.menu.initialize = function (container, loadNodesUrl, autoLoadNodesUrl, showCheckBox, threeState, showRadioBox, nodeClick, nodeCheck, nodeSelect) {
    var tree = new dhtmlXTreeObject(container, "100%", "100%", 0);

    if (showCheckBox) {
        tree.enableCheckBoxes(1);
        if (threeState) {
            tree.enableThreeStateCheckboxes(true);
        }
        //tree.enableThreeStateCheckboxes(true);
        //tree.enableSmartCheckboxes(true);
    }
    if (showRadioBox) {
        tree.enableRadioButtons(1);
        tree.enableSingleRadioMode(1);
    }
    tree.setImagePath('../Resource/Script/dhtmlxtree/imgs/');

    if (autoLoadNodesUrl != null) {
        //异步加载数据的数据源nodeChecked
        tree.setXMLAutoLoading(autoLoadNodesUrl);
    }

    //初次加载数据
    tree.loadXML(loadNodesUrl);

    if (nodeClick != null) {
        tree.attachEvent("onClick", function (id) {
            nodeClick(id, this.getItemText(id), tree);
        });
    }
    if (nodeCheck != null) {
        tree.attachEvent("onCheck", function (id) {
            nodeCheck(id, this.getItemText(id), tree);
        });
    }
    if (nodeSelect != null) {
        tree.attachEvent("onCheck", function (id) {
            nodeSelect(id, this.getItemText(id), tree);
        });
    }
    return tree;
}

$.date = new Object();
$.date.format = function (date, format, zone) {
    format = format.replace("yyyy", date.getFullYear());
    format = format.replace("MM", (date.getMonth() + 1) > 10 ? (date.getMonth() + 1) : "0" + (date.getMonth() + 1))
    format = format.replace("dd", date.getDate() > 10 ? date.getDate() : "0" + date.getDate());
    format = format.replace("HH", date.getHours() > 10 ? date.getHours() : "0" + date.getHours());
    format = format.replace("mm", date.getMinutes() > 10 ? date.getMinutes() : "0" + date.getMinutes());
    format = format.replace("ss", date.getSeconds() > 10 ? date.getSeconds() : "0" + date.getSeconds());
    format = format.replace("fff", date.getMilliseconds() > 100 ? date.getMilliseconds() : "0" + (date.getMilliseconds() > 10 ? date.getMilliseconds() : "0" + date.getMilliseconds()));
    if (zone) {
        format = format.replace(/\b(\d)\b/g, '0$1 ');
    }
    return format;
}
$.date.now = function () {
    return $.date.format(new Date(), "yyyy-MM-dd HH:mm:ss.fff");
}

$.expandShrink = new Object();
$.expandShrink.initialize = function (triggerObj, expandContent, paddingTopHeight) {
    triggerObj = $.getjQueryObj(triggerObj);
    triggerObj.addClass("slexpandShrink-shrink");
    expandContent = $.getjQueryObj(expandContent);
    var expandContentHeight = expandContent.height();

    triggerObj.bind("click", function () {
        if (triggerObj.hasClass("slexpandShrink-expand")) {
            expandContent.next().css("slpadding-top", paddingTopHeight + "px");
            expandContent.show();
            triggerObj.removeClass("slexpandShrink-expand");
            triggerObj.addClass("slexpandShrink-shrink");
        }
        else {
            expandContent.next().css("slpadding-top", "0px");
            expandContent.hide();
            triggerObj.removeClass("slexpandShrink-shrink");
            triggerObj.addClass("slexpandShrink-expand");
        }
    });
}

$.getjQueryObj = function (obj) {
    return typeof obj === "string" ? $("." + obj) : $(obj);
}

/*打开一个iframe窗口，宽度高度自己把握，不要超出外层window大小*/
//添加回掉函数callBack    点击关闭时调用 hmx
$.ifdialog = function (src, width, height, refreshOnClose,callBack) {
    var _doc_width = $(document).width();
    var _doc_height = $(document).height();
    var _html = "<div id='bg' style='position: absolute; z-index: 100000; display: block; left: 0px; top: 0px; opacity: 0.5;filter:alpha(opacity=50); height: " + _doc_width + "px; width: " + _doc_width + "px; background-color:#CCC;'></div>";
    _html += "<div id='ifdiv'style='background-color:#FFF;border:solid 1px #000000;position: fixed; left:" + (_doc_width - width) / 2 + "px; top:32px; z-index:100001;'>";
    _html += "<a style='position: absolute;right: 10px;' onclick='javascript:$.closeifdialog(" + refreshOnClose + ","+callBack+");'>[ 关闭 ]</a>";
    _html += "<div><iframe src='" + src + "' frameborder='0' style='width:" + width + "px;height:" + height + "px;overflow:visible;'></iframe></div></div>";
    $('body').append(_html);
}
/*在iframe直接父层中关闭*/
$.closeifdialog = function (refreshOnClose,callBack) {
    if (refreshOnClose) {
        if ($('#btnSearch').length) {
            $('#btnSearch').click();
        } else {
            window.location.href = window.location.href;
        }
    }
    $('#bg,#ifdiv').remove();
    if (callBack!=undefined) {
        callBack();
    }
}
/*在iframe内关闭*/
$.closeSelf = function (refreshParentOnClose) {
    if (refreshParentOnClose) {
        if (window.parent.$('#btnSearch').length) {
            window.parent.$('#btnSearch').click();
        } else {
            window.parent.location.href = window.parent.location.href;
        }
    }
    window.parent.$('#bg,#ifdiv').remove();
}

function CreateBackDiv() {

    //如果背景层遮罩不存在，并且设置为遮罩效果，则创建

    if ($('#backDiv').length == 0) {

        var backDiv = document.createElement('div');

        backDiv.id = "backDiv";

        backDiv.style.backgroundColor = "Black";

        //backDiv.style.filter = "alpha(opacity=50)";

        //backDiv.style.MozOpacity = "0.50";

        backDiv.style.position = "absolute";

        backDiv.style.left = "0px";

        backDiv.style.top = "0px";

        backDiv.style.width = Math.max(document.body.scrollWidth, document.documentElement.clientWidth) + "px";

        backDiv.style.height = Math.max(document.body.scrollHeight, document.documentElement.clientHeight) + "px";

        document.body.appendChild(backDiv);

        $('#backDiv').css({ "zIndex": 100, "filter": "alpha(opacity=50)", "opacity": 0.5 });

    }
}
function RemoveBackDiv() {
    if ($("#backDiv").length > 0) {
        $("#backDiv").remove();
    }
}


/*******************设置列表表头和分页静止***************************/
$(function () {
    if ($(".slshowPart").length > 0 && $(".sloperatePart").length > 0 && $(".sldatatable").length > 0 && $(".sldatatableheader").length > 0) {

        $(window.parent.document).find("#ifContent").load(function () {

            var main = $(window.parent.document).find("#ifContent");
            var thisheight = 500;
            main.height(thisheight);

            var t = $(window.parent.document).find("#ContentMenuTab");
            if (t.length > 0) {
                var CMT = $(window.parent.document).find("#ContentMenuTab");
                var het = CMT.parent().height() - 45;
                CMT.height(het);
                main.height('100%');
            }
        });

        $(".slpager").css({ "position": "fixed", "bottom": "0", "width": "100%" })
        $(".slshowPart").css({ "position": "fixed", "width": "100%" });
        $('.slshowPart').css('margin-top', $('.sloperatePart').innerHeight());
        $(".sldatatableheaderfix th").css('padding-right', 5);

        var showPartPadd = $('.slshowPart').innerHeight() - $('.slshowPart').height();
        var showPartBord = $('.slshowPart').outerHeight() - $('.slshowPart').innerHeight();
        var showPartMarg = $('.slshowPart').outerHeight(true) - $('.slshowPart').outerHeight();

        var showPartHeight = $('.slshowPart').parent().height() - showPartBord - showPartPadd - showPartMarg;

        $('.slshowPart').height(showPartHeight);
        var sldataHeight = showPartHeight - $('.sldatafix').outerHeight(true) - $('.slpager').outerHeight(true);

        //水平滚动条
        if ($('.slContent').length > 0) {
            $('.sldata').height(sldataHeight - 18);
        }
        else {
            $('.sldata').height(sldataHeight);
        }
        $('.sldata').css('overflow-y', 'scroll');

        var tablerows = $('.sldatatableheader').children();
        var tableheader = $('.sldatatableheaderfix').children();
        $.each(tablerows, function (i, item) {
            if (i == tablerows.length - 1) {
                $(item).width($(tableheader[i]).width() - 17);
            } else {
                $(item).width($(tableheader[i]).width());
            }
        });

        //window.onresize = function () {
        //    $(window.parent.document).find("#ifContent").load(function () {

        //        var ifr = document.getElementById("ifContent");
        //        var cg = document.body.scrollHeight;
        //        //ifr.style.height = +"px";

        //        var main = $(window.parent.document).find("#ifContent");
        //        //var thisheight = document.body.clientHeight;
        //        main.height(cg - 500);
        //    });
        //}


        $(window).resize(function () {

            //var t = $(window.parent.document).find("#ContentMenuTab");
            //if (t.length > 0) {
            //    var CMT = $(window.parent.document).find("#ContentMenuTab");
            //    CMT.height('100%');
            //    CMT.height(CMT.height() - 45);
            //}
            var t = $(window.parent.document).find("#ContentMenuTab");
            if (t.length > 0) {
                var CMT = t;
                CMT.height('100%');
                setTimeout(function () {
                    var het = CMT.height - 45;
                    CMT.height(het);
                }, 500);

            }

            $('.slshowPart').css('margin-top', $('.sloperatePart').innerHeight());

            var showPartPadd = $('.slshowPart').innerHeight() - $('.slshowPart').height();
            var showPartBord = $('.slshowPart').outerHeight() - $('.slshowPart').innerHeight();
            var showPartMarg = $('.slshowPart').outerHeight(true) - $('.slshowPart').outerHeight();

            var showPartHeight = $('.slshowPart').parent().height() - showPartBord - showPartPadd - showPartMarg;

            $('.slshowPart').height(showPartHeight);
            var sldataHeight = showPartHeight - $('.sldatafix').outerHeight(true) - $('.slpager').outerHeight(true);

            $('.slshowPart').height(sldataHeight);

            //水平滚动条
            if ($('.slContent').length > 0) {
                $('.sldata').height(sldataHeight - 18);
            }
            else {
                $('.sldata').height(sldataHeight);
            }
        });
    }
});

/*******************获取本周、本季度、本月、上月的开始日期、结束日期 ***************************/
var now = new Date();                    //当前日期     
var nowDayOfWeek = (now.getDay() == 0) ? 6 : now.getDay() - 1;  //今天是本周的第几天。周一=0，周日=6
var nowDay = now.getDate();              //当前日     
var nowMonth = now.getMonth();           //当前月     
var nowYear = now.getYear();             //当前年     
nowYear += (nowYear < 2000) ? 1900 : 0;  //    

var lastMonthDate = new Date();  //上月日期  
lastMonthDate.setDate(1);
lastMonthDate.setMonth(lastMonthDate.getMonth() - 1);
var lastYear = lastMonthDate.getYear();
var lastMonth = lastMonthDate.getMonth();

//格式化日期：yyyy-MM-dd     
function formatDate(date) {
    var myyear = date.getFullYear();
    var mymonth = date.getMonth() + 1;
    var myweekday = date.getDate();

    if (mymonth < 10) {
        mymonth = "0" + mymonth;
    }
    if (myweekday < 10) {
        myweekday = "0" + myweekday;
    }
    return (myyear + "-" + mymonth + "-" + myweekday);
}
//获取某一天
function getDate(day) {
    return new Date(new Date().getTime() - (day * 24 * 60 * 60 * 1000)).format("yyyy-MM-dd");
}
//获得某月的天数     
function getMonthDays(myMonth) {
    var monthStartDate = new Date(nowYear, myMonth, 1);
    var monthEndDate = new Date(nowYear, myMonth + 1, 1);
    var days = (monthEndDate - monthStartDate) / (1000 * 60 * 60 * 24);
    return days;
}
//获得本季度的开始月份     
function getQuarterStartMonth() {
    var quarterStartMonth = 0;
    if (nowMonth < 3) {
        quarterStartMonth = 0;
    }
    if (2 < nowMonth && nowMonth < 6) {
        quarterStartMonth = 3;
    }
    if (5 < nowMonth && nowMonth < 9) {
        quarterStartMonth = 6;
    }
    if (nowMonth > 8) {
        quarterStartMonth = 9;
    }
    return quarterStartMonth;
}
//获得本周的开始日期     
function getWeekStartDate() {
    var weekStartDate = new Date(nowYear, nowMonth, nowDay - nowDayOfWeek);
    return formatDate(weekStartDate);
}
//获得本周的结束日期     
function getWeekEndDate() {
    var weekEndDate = new Date(nowYear, nowMonth, nowDay + (6 - nowDayOfWeek));
    return formatDate(weekEndDate);
}
//获得本月的开始日期     
function getMonthStartDate() {
    var monthStartDate = new Date(nowYear, nowMonth, 1);
    return formatDate(monthStartDate);
}
//获得本月的结束日期     
function getMonthEndDate() {
    var monthEndDate = new Date(nowYear, nowMonth, getMonthDays(nowMonth));
    return formatDate(monthEndDate);
}
//获得上月开始时间  
function getLastMonthStartDate() {
    var lastMonthStartDate = new Date(nowYear, lastMonth, 1);
    return formatDate(lastMonthStartDate);
}
//获得上月结束时间  
function getLastMonthEndDate() {
    var lastMonthEndDate = new Date(nowYear, lastMonth, getMonthDays(lastMonth));
    return formatDate(lastMonthEndDate);
}
//获得本季度的开始日期     
function getQuarterStartDate() {

    var quarterStartDate = new Date(nowYear, getQuarterStartMonth(), 1);
    return formatDate(quarterStartDate);
}
//或的本季度的结束日期     
function getQuarterEndDate() {
    var quarterEndMonth = getQuarterStartMonth() + 2;
    var quarterStartDate = new Date(nowYear, quarterEndMonth, getMonthDays(quarterEndMonth));
    return formatDate(quarterStartDate);
}
//获取本年数据
function getYearStartDate() {
    var yearStartDate = new Date(nowYear, 0, 1);
    return formatDate(yearStartDate);
}
//获取本年结束日期
function getYearEndDate() {
    var yearEndDate = new Date(nowYear + 1, 0, 1);
    return formatDate(yearEndDate);
}
//千分位
function format(num, point) {
    return (num.toFixed(point) + '').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
}
/*******************扩展日期函数 ***************************/
//增加类型
/*  s：秒
    n：分钟
    h：小时
    d：天
    w：周
    q：季
    m：月
    y年
*/
//Number：数量
Date.prototype.DateAdd = function (strInterval, Number) {
    var dtTmp = this;
    switch (strInterval) {
        case 's': return new Date(Date.parse(dtTmp) + (1000 * Number));
        case 'n': return new Date(Date.parse(dtTmp) + (60000 * Number));
        case 'h': return new Date(Date.parse(dtTmp) + (3600000 * Number));
        case 'd': return new Date(Date.parse(dtTmp) + (86400000 * Number));
        case 'w': return new Date(Date.parse(dtTmp) + ((86400000 * 7) * Number));
        case 'q': return new Date(dtTmp.getFullYear(), (dtTmp.getMonth()) + Number * 3, dtTmp.getDate(), dtTmp.getHours(), dtTmp.getMinutes(), dtTmp.getSeconds());
        case 'm': return new Date(dtTmp.getFullYear(), (dtTmp.getMonth()) + Number, dtTmp.getDate(), dtTmp.getHours(), dtTmp.getMinutes(), dtTmp.getSeconds());
        case 'y': return new Date((dtTmp.getFullYear() + Number), dtTmp.getMonth(), dtTmp.getDate(), dtTmp.getHours(), dtTmp.getMinutes(), dtTmp.getSeconds());
    }
}
$.vform = function (id) {
    var arg = '?';
    if (!id) { id = 'div.slparameterPart'; }
    $(id).find('input').each(function (index, elem) {
        if ($(elem).hasClass('required')) {
            if (!$(elem).val()) {
                $(elem).tooltip($(elem).attr('tip'));
                arg = '';
                return false;
            }
        }
        if ($(elem).hasClass('num')) {
            if (isNaN($(elem).val())) {
                $(elem).tooltip('必须为数字');
                arg = '';
                return false;
            }
        }
    });
    if (arg) {
        $(id).find('input,select').each(function (index, elem) {
            arg += $(elem).attr('id') + '=' + encodeURI($(elem).val()) + '&';
        });
        $(id).find('textarea').each(function (index, elem) {
            arg += $(elem).attr('id') + '=' + encodeURI($(elem).val()) + '&';
        });
        return arg;
    } else {
        return false;
    }
}
$.qform = function (id) {
    var q = '?';
    if (!id) { id = 'div.slparameterPart'; }
    $(id).find('input,select').each(function (index, elem) {
        if ($(elem).attr('id') == 'citySelect') {
            q += $(elem).attr('id') + '=' + encodeURI($('option:selected', elem).text()) + '&';
        } else {
            q += $(elem).attr('id') + '=' + encodeURI($(elem).val()) + '&';
        }
    });
    if ($('#txtPageSize').length) { q += 'pageSize=' + $('#txtPageSize').val() + '&'; }
    if ($('#txtCurrentPage').length) { q += 'pageIndex=' + $('#txtCurrentPage').val() + '&'; }
    return q;
}
$.tabs.refreshMenu0 = function (tabitemName, tabitemUrl) {
    var flag = 0;
    $('.sltabitemheaderbutton').each(function () {
        if ($(this).text().replace(/\s/g, "") == tabitemName) {
            $('#tabs').tabs("select", tabitemName);
            $($(this).attr("href")).attr("src", tabitemUrl);
            flag++;
        }
    });
    if (flag == 0) {
        $.tabs.openMenu(tabitemName, tabitemUrl);
    }
}
$.tabs.closeMenu0 = function (tabitemName) {
    $('.sltabitemheaderbutton').each(function () {
        if ($(this).text().replace(/\s/g, "") == tabitemName) {
            $('#tabs').tabs("remove", tabitemName);
        }
    });
}