﻿
//折线图方法
function GetLineMethod(ContentID, ChartText, ChartXContent, ChartSuffix, ChartData, ShowValue) {
    var charid = "#" + ContentID;//div ID值
    $(charid).highcharts({
        //chart: {
        //    //width: 1100,
        //    //height: 300
        //},
        title: {
            text: ChartText,  //标题
            x: -140
        },
        subtitle: {
            text: '',
            x: -20
        },
        xAxis: {
            categories: ChartXContent,  //要显示的X轴的值
            labels: { rotation: -45, y: 30 }
        },
        yAxis: {
            title: {
                text: ''
            },
            min: 0,
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ChartSuffix   //单位，比如“人”
        },
        plotOptions: { line: { dataLabels: { enabled: ShowValue }, enableMouseTracking: true } },
        legend: {
            //layout: 'vertical',
            //align: 'center',  //显示位置
            //verticalAlign: 'middle',
            borderWidth: 0
        },
        series: ChartData,  //最终显示的数据
        // setSize: { width:'100%' },//Number width, Number height, [Mixed animation])
        credits: {
            enabled: false
        }
    });
}
//饼形图方法
function Get_Pie(ContenID, ChartTest, Cdata, Cwidth, Csubtitle) {
    var chartid = "#" + ContenID;//div ID值
    $(function () {
        $(chartid).highcharts({
            chart: {
                width: Cwidth,//400,
                height: 300
                //plotBackgroundColor: null,
                //plotBorderWidth: null,
                //plotShadow: false
            },
            title: {
                text: ChartTest
            },
            subtitle: {
                //text: '项目执行期内所有客户数据',
                text: Csubtitle,
                style: {
                    color: '#DA0000',
                    fontSize: '12px'
                },
                x: -6
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            legend: {
                //layout: 'vertical',
                //align: 'center',  //显示位置
                //verticalAlign: 'middle',
                borderWidth: 0
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        color: '#000000',
                        //style: {
                        //    fontSize:'10px'
                        //},
                        distance: 15,
                        connectorPadding: 5,
                        connectorColor: '#000000',//<b>{point.name}</b>: {point.percentage:.1f} %
                        //format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                        format: '<b>{point.name}</b>, {point.y},{point.percentage:.1f} %'

                    },
                    showInLegend: true
                }
            },
            noData: {
                attr: null,
                position: { "x": 0, "y": 0, "align": "center", "verticalAlign": "middle" },
                style: { "fontSize": "12px", "fontWeight": "bold", "color": "#60606a" }
            },
            series: Cdata,
            credits: {
                enabled: false
            }
        });
    });

}
//条形图方法
function GetTiaoTuMethod(ContenID, Ydata) {
    var chartid = "#" + ContenID;//div ID值
    $(function () {
        $(chartid).highcharts({
            chart: {
                type: 'bar'
            },
            title: {
                text: null
            },
            subtitle: {
                //text: 'Source: Wikipedia.org'                                  
            },
            xAxis: {
                categories: ['PC', 'Wap', 'App'],
                title: {
                    text: null
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            tooltip: {
                //valueSuffix: ' millions'                                       
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                borderWidth: 0,
                backgroundColor: '#FFFFFF',
                shadow: false

            },
            credits: {
                enabled: false
            },
            series: Ydata
        });
    });
}

function Round30X(orginalX) {
    if (orginalX.length > 30) {
        var rtn = new Array();
        var step = Math.ceil(orginalX.length / 30);
        for (var i = 0; i < orginalX.length; i++) {
            if (!(i % step)) {
                rtn.push(orginalX[i]);
            }
        }
        return rtn;
    } else {
        return orginalX;
    }
}
function Round30Y(orginalY) {
    for (var i = 0; i < orginalY.length; i++) {
        if (orginalY[i].data.length > 30) {
            var rtn = new Array();
            var step = Math.ceil(orginalY[i].data.length / 30);
            for (var j = 0; j < orginalY[i].data.length; j++) {
                if (!(j % step)) {
                    rtn.push(orginalY[i].data[j]);
                }
            }
        }
        else {
            return orginalY;
        }
        orginalY[i].data = rtn;
    }
    return orginalY;
}

//红包趋势图(折线图)
function GetRedBagStatistics(Chartdiv, StartTime, EndTime, SelectCity,OrderRange) {
    $.ajax({
        type: "POST",
        url: "GetRedBagTrend.do?t=" + Math.random(),
        cache: false,
        data: {
            starttime: StartTime,
            endtime: EndTime,
            city: SelectCity,
            OrderRange: OrderRange
        },
        success: function (data) {
            if (data != null && data != "") {
                var ddresult = data.split("&");
                var resultF = Round30Y(eval(ddresult[0]));
                var DataJson = Round30X(eval(ddresult[1]));//时间
                //Get_Pie(Chartdiv, "订单来源", resultF, 350, "");//饼图     
                //GetChartData(ddresult[1]);
                GetLineMethod(Chartdiv, "红包趋势图", DataJson, "个", resultF, true); //折线图 ShowChartPie
            }
            else {
                $("#ShowChartLine").html("<div style='width: 100%; height: 300px;font-size:18px;text-align:center;'><span style='color: #F00'>红包趋势图无数据</span></div>");

            }
        }
    });
}

//领取红包来源(饼形图)
function GetRedBagPieFrom(Chartdiv, StartTime, EndTime, SelectCity) {
    $.ajax({
        type: "POST",
        url: "GetRedBagPie.do?t=" + Math.random(),
        cache: false,
        data: {
            StartTime: StartTime,
            Endtime: EndTime,
            City: SelectCity
        },
        success: function (data) {
            if (data != null && data != "") {
                var ddresult = data.split("#");
                var resultF = eval(ddresult[0]);
                Get_Pie(Chartdiv, "红包领取来源分析图", resultF, 350, "");//饼图     
                //GetChartData(ddresult[1]);
            }
            else {
                $("#ShowRedBagPie").html("<div style='width: 100%; height: 300px;font-size:18px;text-align:center;'><span style='color: #F00'>红包领取来源无数据</span></div>");

            }
        }
    });
}

//领取红包来源（条形图）
function GetRedBagBarFrom(Chartdiv, StartTime, EndTime, SelectCity) {
    $.ajax({
        type: "POST",
        url: "GetRedBagBar.do?t=" + Math.random(),
        cache: false,
        data: {
            StartTime: StartTime,
            Endtime: EndTime,
            City: SelectCity
        },
        success: function (data) {
            if (data != null && data != "") {
                var resultF = eval(data);
                GetTiaoTuMethod(Chartdiv, resultF);//条形图    
            }
            else {
                $("#ShowRedBagBar").html("<div style='width: 100%; height: 300px;font-size:18px;text-align:center;'><span style='color: #F00'>红包领取来源无数据</span></div>");

            }
        }
    });
}





